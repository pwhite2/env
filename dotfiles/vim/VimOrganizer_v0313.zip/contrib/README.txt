The vim73 patch in this directory does two things:

1. Enables level-dependent fold highlighting in Vim73.
2. Enables separate TODO highlighting in folded headings
   in VimOrganizer, so TODO's stand out even when a
   heading is folded.

The vim72 patch is old and only does (1) above.

If someone is using a version of Windows and wants to avoid
recompiling process you can contact me and I will send you an
executable you should be able to use on your system.

Herbert Sitz
hesitz@gmail.com
